<?php

$sql_server='localhost';
$sql_username='root';
$sql_password='';
$sql_database='medtech';
?>